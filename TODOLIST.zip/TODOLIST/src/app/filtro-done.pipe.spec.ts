import { FiltroDonePipe } from './filtro-done.pipe';

describe('FiltroDonePipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroDonePipe();
    expect(pipe).toBeTruthy();
  });
});
