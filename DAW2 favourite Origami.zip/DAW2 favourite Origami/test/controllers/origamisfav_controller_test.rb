require 'test_helper'

class OrigamisfavControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get origamisfav_index_url
    assert_response :success
  end

end
