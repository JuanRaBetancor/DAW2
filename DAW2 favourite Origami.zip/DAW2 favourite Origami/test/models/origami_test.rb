require 'test_helper'

class OrigamiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
