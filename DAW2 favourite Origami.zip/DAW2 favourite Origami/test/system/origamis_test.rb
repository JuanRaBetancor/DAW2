require "application_system_test_case"

class OrigamisTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit origamis_url
  #
  #   assert_selector "h1", text: "Origami"
  # end
end
