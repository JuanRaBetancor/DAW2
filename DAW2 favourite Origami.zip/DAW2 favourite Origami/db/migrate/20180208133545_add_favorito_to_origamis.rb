class AddFavoritoToOrigamis < ActiveRecord::Migration[5.1]
  def change
    add_column :origamis, :favorito, :integer
    change_column_default :origamis, :favorito, 0
  end
end
