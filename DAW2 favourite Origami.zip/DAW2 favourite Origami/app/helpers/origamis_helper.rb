module OrigamisHelper
end
