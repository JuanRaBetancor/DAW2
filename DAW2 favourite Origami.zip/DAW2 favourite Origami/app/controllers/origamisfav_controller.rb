class OrigamisfavController < ApplicationController
  def index
    @origamis = Origami.favoritos
  end
end
