class Origami < ApplicationRecord
 mount_uploader :imagen, ImageUploader
 default_scope {order 'lower(nombre)'}

 scope :favoritos, -> { where(favorito: 1) }
 scope :setFavorito, -> (id, favorito) {
  origami = Origami.find(id)
  origami.favorito = favorito
  origami.save
 }

end
